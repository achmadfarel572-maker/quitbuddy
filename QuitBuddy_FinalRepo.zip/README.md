# QuitBuddy Final Repo

This repository contains a simple QuitBuddy application (frontend + backend) ready to upload to GitHub.

## Quick start

1. Start backend:

```
cd backend
npm install
node server.js
```

2. Open app/index.html in your browser.

## Build Windows installer

- Replace `app/` into an Electron project and add electron-builder config (I can provide guidance). Or use the Electron installer repo I provided earlier.

