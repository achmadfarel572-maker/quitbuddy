const API = 'http://localhost:4000/api';

async function api(path, method='GET', body){
  const res = await fetch(API + path, body? { method, headers: {'Content-Type':'application/json'}, body: JSON.stringify(body) } : { method });
  return res.json();
}

async function refreshUsers(){
  const users = await api('/users');
  const sel = document.getElementById('selectUser');
  const s2 = document.getElementById('selectUserStats');
  sel.innerHTML = '<option value="">-- pilih pengguna --</option>';
  s2.innerHTML = '<option value="">-- pilih pengguna --</option>';
  users.forEach(u => {
    const o = document.createElement('option'); o.value = u.id; o.text = u.name + ' ('+ (u.age||'') +')'; sel.appendChild(o);
    const o2 = o.cloneNode(true); s2.appendChild(o2);
  });
}

document.getElementById('btnCreateUser').addEventListener('click', async ()=>{
  const name = document.getElementById('name').value.trim();
  const age = parseInt(document.getElementById('age').value)||null;
  const habits = []; if(document.getElementById('habit_smoke').checked) habits.push('smoke'); if(document.getElementById('habit_alcohol').checked) habits.push('alcohol');
  const avgDaily = parseFloat(document.getElementById('avgDaily').value)||0;
  const priceUnit = parseFloat(document.getElementById('priceUnit').value)||0;
  if(!name){ alert('Masukkan nama'); return; }
  const out = await api('/users', 'POST', { name, age, habits, avgDailyConsumption: avgDaily, pricePerUnit: priceUnit });
  document.getElementById('userMsg').innerText = 'Pengguna dibuat: ' + out.user.id;
  document.getElementById('name').value='';
  await refreshUsers();
});

document.getElementById('btnSaveReport').addEventListener('click', async ()=>{
  const userId = document.getElementById('selectUser').value;
  const date = document.getElementById('rDate').value || new Date().toISOString().slice(0,10);
  const cigs = parseInt(document.getElementById('rCigs').value)||0;
  const drinks = parseInt(document.getElementById('rDrinks').value)||0;
  const mood = document.getElementById('rMood').value;
  const note = document.getElementById('rNote').value;
  if(!userId){ alert('Pilih pengguna'); return; }
  const out = await api('/reports', 'POST', { userId, date, cigs, drinks, mood, note });
  document.getElementById('reportMsg').innerText = 'Laporan tersimpan: ' + out.report.id;
});

document.getElementById('btnLoadStats').addEventListener('click', async ()=>{
  const userId = document.getElementById('selectUserStats').value;
  if(!userId){ alert('Pilih pengguna'); return; }
  const out = await api('/stats/' + userId);
  const area = document.getElementById('statsArea');
  area.innerHTML = '<h3>Ringkasan 7 hari</h3>';
  out.last7.forEach(d => { area.innerHTML += `<div>${d.date}: Rokok ${d.cigs}, Alkohol ${d.drinks}</div>`; });
  area.innerHTML += `<div>Perkiraan penghematan minggu ini: Rp ${out.moneySaved.toLocaleString()}</div>`;
  const sugg = document.getElementById('suggestions'); sugg.innerHTML='';
  if(out.last7.some(d=>d.cigs>0)) sugg.innerHTML += '<div>Aktivitas: Jalan cepat 10 menit</div>';
  if(out.last7.some(d=>d.drinks>0)) sugg.innerHTML += '<div>Aktivitas: Minum air & istirahat</div>';
  area.innerHTML += '<h4>Risiko</h4><div>' + out.risks.join(' | ') + '</div>';
});

// static lists
const activities = ['Jalan cepat','Tarik napas 5 menit','Mendengarkan musik','Menulis jurnal'];
const diseases = ['Kanker paru','Penyakit jantung','Sirosis hati','Pankreatitis'];
window.addEventListener('DOMContentLoaded', ()=>{
  const a = document.getElementById('activities'); activities.forEach(x=>{ const li=document.createElement('li'); li.innerText=x; a.appendChild(li); });
  const d = document.getElementById('diseases'); diseases.forEach(x=>{ const li=document.createElement('li'); li.innerText=x; d.appendChild(li); });
  document.getElementById('rDate').value = new Date().toISOString().slice(0,10);
  refreshUsers();
});
