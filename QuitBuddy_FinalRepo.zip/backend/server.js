require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const app = express();
app.use(cors()); app.use(express.json());
const DATA_DIR = path.join(__dirname,'data'); if(!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR);
const USERS_FILE = path.join(DATA_DIR,'users.json'); const REPORTS_FILE = path.join(DATA_DIR,'reports.json');
if(!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE,'[]'); if(!fs.existsSync(REPORTS_FILE)) fs.writeFileSync(REPORTS_FILE,'[]');
function readJSON(file){ return JSON.parse(fs.readFileSync(file,'utf-8')); }
function writeJSON(file,data){ fs.writeFileSync(file,JSON.stringify(data,null,2)); }
app.get('/api/health',(req,res)=>res.json({status:'ok'}));
app.post('/api/users',(req,res)=>{ const users=readJSON(USERS_FILE); const id='u'+Date.now().toString(36); const user=Object.assign({id,createdAt:new Date().toISOString()},req.body); users.push(user); writeJSON(USERS_FILE,users); res.json({message:'user created',user}); });
app.get('/api/users',(req,res)=>res.json(readJSON(USERS_FILE)));
app.post('/api/reports',(req,res)=>{ const reports=readJSON(REPORTS_FILE); const id='r'+Date.now().toString(36); const report=Object.assign({id,createdAt:new Date().toISOString()},req.body); reports.push(report); writeJSON(REPORTS_FILE,reports); res.json({message:'report saved',report}); });
app.get('/api/reports/:userId',(req,res)=>{ const userId=req.params.userId; const reports=readJSON(REPORTS_FILE).filter(r=>r.userId===userId); res.json(reports); });
app.get('/api/stats/:userId',(req,res)=>{ const userId=req.params.userId; const users=readJSON(USERS_FILE); const user=users.find(u=>u.id===userId); if(!user) return res.status(404).json({error:'user not found'}); const reports=readJSON(REPORTS_FILE).filter(r=>r.userId===userId); const last7=[]; const today=new Date(); for(let i=6;i>=0;i--){ const d=new Date(); d.setDate(today.getDate()-i); const key=d.toISOString().slice(0,10); const dayReports=reports.filter(r=>r.date===key); const sumCigs=dayReports.reduce((s,r)=>s + (r.cigs||0),0); const sumDrinks=dayReports.reduce((s,r)=>s + (r.drinks||0),0); last7.push({date:key,cigs:sumCigs,drinks:sumDrinks}); } const baselineWeekly=(user.avgDailyConsumption||0)*7*(user.pricePerUnit||0); const actualWeekly=last7.reduce((s,d)=> s + (d.cigs||0) * (user.pricePerUnit||0), 0); const moneySaved=Math.max(0, baselineWeekly - actualWeekly); const risks=[]; if((user.habits||[]).includes('smoke')) risks.push('Merokok: kanker paru, PPOK, penyakit jantung, stroke.'); if((user.habits||[]).includes('alcohol')) risks.push('Alkohol: sirosis hati, pankreatitis, gangguan neurologis.'); res.json({user,last7,moneySaved,risks}); });
const PORT=process.env.PORT||4000; app.listen(PORT,()=>console.log('Server listening on',PORT));